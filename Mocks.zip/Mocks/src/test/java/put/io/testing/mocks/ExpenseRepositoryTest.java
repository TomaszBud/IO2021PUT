package put.io.testing.mocks;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InOrder;

import put.io.students.fancylibrary.database.FancyDatabase;
import put.io.students.fancylibrary.database.IFancyDatabase;
public class ExpenseRepositoryTest {

    private ExpenseRepository expenses;
//    private FancyDatabase nazwa;
    private ArrayList<ArrayList> expected;



    @Test
    void loadExpenses() {
        expenses.loadExpenses();
        expected = new ArrayList<ArrayList>();
        assertEquals(expected, expenses.getExpenses());
    }

    @BeforeEach
    void setUp() throws Exception{
        IFancyDatabase nazwa = new MyDatabase();
        expenses = new ExpenseRepository(nazwa);
    }
}
