package put.io.testing.mocks;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static org.mockito.Mockito.*;

import org.mockito.InjectMocks;
import put.io.students.fancylibrary.database.IFancyDatabase;

public class MyDatabase implements IFancyDatabase {

//    IFancyDatabase fancyDatabase = null;
//    @Mock fancyDatabase dataMock;
    IFancyDatabase mocked = mock(IFancyDatabase.class);
//    mocked = new FancyDatabase();
    public List<Expense> queryAll() {
        return Collections.emptyList();
    }

    @Override
    public void connect() {
    }

    @Override
    public <T> void persist(T t) {
    }

    @Override
    public void close() {
    }
}
